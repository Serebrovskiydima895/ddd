import sys

from PyQt5.QtWidgets import QApplication, QWidget, QPushButton, QVBoxLayout, QLineEdit, QComboBox, QGridLayout
from PyQt5.QtWidgets import QMainWindow, QLabel


class FirstForm(QMainWindow):
    def __init__(self):
        super().__init__()
        self.initUI()

    def initUI(self):
        self.setWindowTitle("Конвертер единиц")
        self.setGeometry(100, 100, 400, 200)

    def initUI(self):
        self.central_widget = QWidget()
        self.setCentralWidget(self.central_widget)

        layout = QVBoxLayout()

        self.input_value = QLineEdit()
        layout.addWidget(self.input_value)

        self.unit_from = QComboBox()
        self.unit_from.addItems(["см", "м", "км", "мм", "кг", "г"])
        layout.addWidget(self.unit_from)

        self.print_value = QLineEdit()
        layout.addWidget(self.print_value)

        self.unit_to = QComboBox()
        self.unit_to.addItems(["см", "м", "км", "мм", "кг", "г"])
        layout.addWidget(self.unit_to)

        self.result_label = QLabel()
        layout.addWidget(self.result_label)

        self.calculate_button = QPushButton("Конвертировать")
        layout.addWidget(self.calculate_button)

        self.calculate_button.clicked.connect(self.convert_units)

        self.central_widget.setLayout(layout)

        self.btn = QPushButton('Калькулятор', self)
        self.btn.resize(200, 30)
        self.btn.move(0, 150)

        self.btn.clicked.connect(self.open_second_form)

        self.btn1 = QPushButton('Калькулятор Валют', self)
        self.btn1.resize(200, 30)
        self.btn1.move(210, 150)

        self.btn1.clicked.connect(self.open_third_form)

        self.btn2 = QPushButton('Калькулятор Систем Исчесления', self)
        self.btn2.resize(200, 30)
        self.btn2.move(420, 150)

        self.btn2.clicked.connect(self.open_four_form)

    def convert_units(self):
        try:
            value = float(self.input_value.text())
            unit_from = self.unit_from.currentText()
            unit_to = self.unit_to.currentText()

            # Define conversion factors
            conversion_factors = {
                "см": {"м": 0.01, "км": 0.00001, "см": 1, "мм": 10},
                "м": {"м": 1, "см": 100, "км": 0.001, "мм": 1000, },
                "км": {"км": 1, "см": 100000, "м": 1000, "мм": 1000000},
                "мм": {"см": 0.1, "мм": 1, "м": 0.001, "км": 0.000001},
                "кг": {"г": 1000},
                "г": {"кг": 0.001}
            }

            # Perform the conversion
            result = value * conversion_factors[unit_from][unit_to]
            self.print_value.setText(f"{result} {unit_to}")

        except ValueError:
            self.print_value.setText("Введите числовое значение")
        except KeyError:
            self.print_value.setText("Error")

    def open_second_form(self):
        self.second_form = SecondForm(self, "Данные для второй формы")
        self.second_form.show()

    def open_third_form(self):
        self.third_form = ThirdForm(self, ",,,")
        self.third_form.show()

    def open_four_form(self):
        self.four_form = FourForm(self, ",,,")
        self.four_form.show()


class SecondForm(QWidget):
    def __init__(self, *args):
        super().__init__()
        self.initUI(args)

    def initUI(self, args):
        self.setWindowTitle('Калькулятор')
        self.setGeometry(100, 100, 300, 400)

        self.layout = QVBoxLayout()
        self.textbox = QLineEdit(self)
        self.layout.addWidget(self.textbox)

        grid = QGridLayout()
        buttons = [
            '7', '8', '9', '/',
            '4', '5', '6', '*',
            '1', '2', '3', '-',
            '0', '.', '+', '=',
            '<-'
        ]
        positions = [(i, j) for i in range(5) for j in range(4)]

        for position, button in zip(positions, buttons):
            button_widget = QPushButton(button)
            grid.addWidget(button_widget, *position)
            button_widget.clicked.connect(self.button_click)

        clear_button = QPushButton('C')
        clear_button.clicked.connect(self.clear_text)
        grid.addWidget(clear_button, 0, 0)

        self.layout.addLayout(grid)
        self.setLayout(self.layout)

    def button_click(self):
        button_text = self.sender().text()
        current_text = self.textbox.text()

        if button_text == '=':
            try:
                result = eval(current_text)
                self.textbox.setText(str(result))
            except Exception as e:
                self.textbox.setText('Ошибка')
        elif button_text == '<-':
            self.textbox.setText(current_text[:-1])
        else:
            self.textbox.setText(current_text + button_text)

    def clear_text(self):
        self.textbox.setText('')


class ThirdForm(QMainWindow):
    def __init__(self, *args):
        super().__init__()
        self.initUI(args)

    def initUI(self, args):
        self.setWindowTitle("Калькулятор валют")
        self.setGeometry(100, 100, 400, 200)

        self.central_widget = QWidget()

        self.setCentralWidget(self.central_widget)

        layout = QVBoxLayout()

        self.input_value = QLineEdit()
        layout.addWidget(self.input_value)

        self.unit_from = QComboBox()
        self.unit_from.addItems(
            ["Амерекансий Доллар", "Евро", "Российский рубль", "Швейцарский франк", "Китайский юань",
             "Израильский шекель",
             "Белорусский рубль"])

        layout.addWidget(self.unit_from)

        self.print_value = QLineEdit()

        layout.addWidget(self.print_value)

        self.unit_to = QComboBox()
        self.unit_to.addItems(
            ["Амерекансий Доллар", "Евро", "Российский рубль", "Швейцарский франк", "Китайский юань",
             "Израильский шекель",
             "Белорусский рубль"])

        layout.addWidget(self.unit_to)

        self.result_label = QLabel()
        layout.addWidget(self.result_label)

        self.calculate_button = QPushButton("Конвертировать")
        layout.addWidget(self.calculate_button)

        self.calculate_button.clicked.connect(self.convert_units)

        self.central_widget.setLayout(layout)

    def convert_units(self):
        try:
            value = float(self.input_value.text())
            unit_from = self.unit_from.currentText()
            unit_to = self.unit_to.currentText()

            conversion_factors = {
                "Амерекансий Доллар": {"Евро": 0.95, "Российский рубль": 93.16, "Швейцарский франк": 0.90,
                                       "Китайский юань": 7.32, "Израильский шекель": 4.05,
                                       "Белорусский рубль": 3.29, "Амерекансий Доллар": 1},
                "Евро": {"Евро": 1, "Амерекансий Доллар": 93.16, "Российский рубль": 1, "Швейцарский франк": 0.96,
                         "Китайский юань": 7.75, "Израильский шекель": 4.29, "Белорусский рубль": 3.48},
                "Российский рубль": {"Евро": 0.0101, "Амерекансий Доллар": 0.0107, "Российский рубль": 1,
                                     "Швейцарский франк": 0.0097,
                                     "Китайский юань": 0.0786, "Израильский шекель": 0.44,
                                     "Белорусский рубль": 0.036},
                "Швейцарский франк": {"Евро": 1, "Амерекансий Доллар": 100, "Российский рубль": 93.16,
                                      "Швейцарский франк": 1,
                                      "Китайский юань": 7.32, "Израильский шекель": 4.48,
                                      "Белорусский рубль": 3.65},
                "Китайский юань": {"Евро": 1, "Амерекансий Доллар": 100, "Российский рубль": 93.16,
                                   "Швейцарский франк": 0.90,
                                   "Китайский юань": 1, "Израильский шекель": 4.05, "Белорусский рубль": 3.29},
                "Израильский шекель": {"Евро": 1, "Амерекансий Доллар": 100, "Российский рубль": 93.16,
                                       "Швейцарский франк": 0.90,
                                       "Китайский юань": 7.32, "Израильский шекель": 1, "Белорусский рубль": 3.29},
                "Белорусский рубль": {"Евро": 1, "Амерекансий Доллар": 100, "Российский рубль": 93.16,
                                      "Швейцарский франк": 0.90,
                                      "Китайский юань": 7.32, "Израильский шекель": 4.05, "Белорусский рубль": 1}
            }

            result = value * conversion_factors[unit_from][unit_to]
            self.print_value.setText(f"{result} {unit_to}")

        except ValueError:
            self.print_value.setText("Введите числовое значение")

        except KeyError:
            self.print_value.setText("Error")


class FourForm(QMainWindow):
    def __init__(self, *args):
        super().__init__()
        self.initUI(args)

    def initUI(self, args):
        self.setWindowTitle('Калькулятор систем исчисления')
        self.setGeometry(100, 100, 300, 200)

        self.central_widget = QWidget()
        self.setCentralWidget(self.central_widget)

        self.layout = QVBoxLayout()
        self.central_widget.setLayout(self.layout)

        self.number_label = QLabel('Число:')
        self.layout.addWidget(self.number_label)

        self.number_text = QLineEdit()
        self.layout.addWidget(self.number_text)

        self.from_label = QLabel('Из системы:')
        self.layout.addWidget(self.from_label)

        self.from_combobox = QComboBox()
        self.from_combobox.addItem('2')
        self.from_combobox.addItem('10')
        self.from_combobox.addItem('8')
        self.from_combobox.addItem('16')
        self.layout.addWidget(self.from_combobox)

        self.print_text = QLineEdit()
        self.layout.addWidget(self.print_text)

        self.to_label = QLabel('В систему:')
        self.layout.addWidget(self.to_label)

        self.to_combobox = QComboBox()
        self.to_combobox.addItem('2')
        self.to_combobox.addItem('10')
        self.to_combobox.addItem('8')
        self.to_combobox.addItem('16')
        self.layout.addWidget(self.to_combobox)

        self.convert_button = QPushButton('Конвертировать')
        self.convert_button.clicked.connect(self.convert_number)
        self.layout.addWidget(self.convert_button)

        self.result_label = QLabel()
        self.layout.addWidget(self.result_label)

    def convert_number(self):
        number = self.number_text.text()
        from_system = int(self.from_combobox.currentText())
        to_system = int(self.to_combobox.currentText())

        try:
            decimal_value = int(number, from_system)
        except ValueError:
            self.print_text.setText('Некорректное число')
            return

        converted_number = format(decimal_value, 'X') if to_system == 16 else format(decimal_value, f'{to_system}d')
        self.print_text.setText(f'Результат: {converted_number}')


if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = FirstForm()
    ex.show()
    sys.exit(app.exec())
